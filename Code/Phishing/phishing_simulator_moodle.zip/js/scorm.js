// SCORM 1.2 API Wrapper
var SCORM = (function() {
  var API = null;
  var initialized = false;

  function findAPI(win) {
    var tries = 0;
    while (!win.API && win.parent && win.parent != win && tries < 10) {
      win = win.parent;
      tries++;
    }
    return win.API || null;
  }

  function init() {
    API = findAPI(window);
    if (!API && window.opener) API = findAPI(window.opener);
    if (!API) { console.warn("SCORM API not found – running standalone"); return false; }
    var result = API.LMSInitialize("");
    initialized = (result === "true" || result === true);
    return initialized;
  }

  function set(element, value) {
    if (!API) return;
    API.LMSSetValue(element, value);
  }

  function get(element) {
    if (!API) return "";
    return API.LMSGetValue(element);
  }

  function commit() {
    if (!API) return;
    API.LMSCommit("");
  }

  function finish(score, passed) {
    if (!API) return;
    set("cmi.core.score.raw", score);
    set("cmi.core.score.min", "0");
    set("cmi.core.score.max", "100");
    set("cmi.core.lesson_status", passed ? "passed" : "failed");
    commit();
    API.LMSFinish("");
  }

  return { init: init, set: set, get: get, commit: commit, finish: finish };
})();

window.addEventListener("load", function() { SCORM.init(); });
window.addEventListener("beforeunload", function() { SCORM.commit(); });
