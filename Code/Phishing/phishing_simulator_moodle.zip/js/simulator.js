// Phishing Simulator – Kern-Logik

var EMAILS = [
  {
    id: 1,
    isPhishing: true,
    difficulty: "leicht",
    from_name: "PayPal Sicherheit",
    from_email: "security@paypa1-verify.com",
    to: "max.muster@firma.ch",
    subject: "Dringende Sicherheitswarnung: Konto gesperrt!",
    date: "Mo, 27. Mai 2026, 02:14",
    body: `<p>Sehr geehrter Kunde,</p>
<p>Wir haben <strong>verdächtige Aktivitäten</strong> auf Ihrem PayPal-Konto festgestellt. Aus Sicherheitsgründen wurde Ihr Konto <strong style="color:#c0392b">temporär gesperrt</strong>.</p>
<p>Um Ihr Konto wiederherzustellen, müssen Sie Ihre Daten innerhalb von <strong>24 Stunden</strong> bestätigen. Andernfalls wird Ihr Konto dauerhaft geschlossen.</p>
<div style="text-align:center;margin:20px 0">
  <a href="#" onclick="return false" style="background:#003087;color:#fff;padding:12px 28px;border-radius:4px;text-decoration:none;font-weight:bold;display:inline-block">KONTO JETZT ENTSPERREN</a>
</div>
<p>Mit freundlichen Grüssen,<br>PayPal Sicherheitsteam</p>`,
    clues: [
      { element: "from_email", text: "Absender-Adresse: «paypa1-verify.com» – das ist eine «1» statt «l». Keine echte PayPal-Domain." },
      { element: "date", text: "Versanduhrzeit 02:14 Uhr – legitime Unternehmen versenden selten mitten in der Nacht." },
      { element: "urgency", text: "Druck durch Zeitlimit («24 Stunden») und Drohung («dauerhaft geschlossen») – klassisches Phishing-Muster." },
      { element: "link", text: "Der Button führt zu einer unbekannten URL, nicht zu paypal.com." }
    ],
    explanation: "Diese Mail imitiert PayPal, enthält aber eine gefälschte Absender-Domain (paypa1 statt paypal), erzeugt künstlichen Zeitdruck und verlinkt auf eine Phishing-Seite."
  },
  {
    id: 2,
    isPhishing: false,
    difficulty: "mittel",
    from_name: "IT-Helpdesk Firma AG",
    from_email: "helpdesk@firma.ch",
    to: "max.muster@firma.ch",
    subject: "Geplante Wartung – System offline Sa. 31. Mai 2026",
    date: "Di, 28. Mai 2026, 09:05",
    body: `<p>Liebe Mitarbeitende</p>
<p>Wir informieren Sie über eine geplante Systemwartung am kommenden Samstag, 31. Mai 2026, von 08:00 bis 12:00 Uhr.</p>
<p>Folgende Systeme sind betroffen:</p>
<ul>
  <li>E-Mail-Server (Exchange)</li>
  <li>VPN-Zugang</li>
  <li>Intranet-Portal</li>
</ul>
<p>Bitte speichern Sie Ihre Arbeit rechtzeitig und planen Sie entsprechend. Bei Fragen stehen wir unter <strong>helpdesk@firma.ch</strong> oder Tel. 044 123 45 67 zur Verfügung.</p>
<p>Freundliche Grüsse<br>IT-Helpdesk Team<br>Firma AG</p>`,
    clues: [
      { element: "from_email", text: "Die Absender-Domain «firma.ch» stimmt mit der Empfänger-Domain überein – intern und plausibel." },
      { element: "no_urgency", text: "Kein Zeitdruck, keine Drohungen – reine Information über einen geplanten Vorgang." },
      { element: "no_link", text: "Kein verdächtiger Link oder Button – nur eine Kontaktangabe." },
      { element: "content", text: "Der Inhalt ist konkret, sachlich und enthält keine Aufforderung zur Dateneingabe." }
    ],
    explanation: "Diese Mail ist legitim: Die Absender-Domain ist intern konsistent, es gibt keinen Druck, keine verdächtigen Links und keine Dateneingabe-Aufforderung."
  },
  {
    id: 3,
    isPhishing: true,
    difficulty: "schwer",
    from_name: "Microsoft 365",
    from_email: "noreply@microsoft-365-support.net",
    to: "max.muster@firma.ch",
    subject: "Ihre Microsoft 365-Lizenz läuft ab – Jetzt erneuern",
    date: "Mi, 29. Mai 2026, 11:42",
    body: `<p>Sehr geehrte/r Max Muster,</p>
<p>Ihre Microsoft 365 Business-Lizenz läuft am <strong>31. Mai 2026</strong> ab. Um eine Unterbrechung Ihres Dienstes zu vermeiden, erneuern Sie Ihr Abonnement noch heute.</p>
<table style="border:1px solid #ddd;width:100%;border-collapse:collapse;font-size:14px">
  <tr style="background:#f3f3f3"><td style="padding:8px"><b>Produkt</b></td><td style="padding:8px">Microsoft 365 Business Standard</td></tr>
  <tr><td style="padding:8px"><b>Ablaufdatum</b></td><td style="padding:8px">31. Mai 2026</td></tr>
  <tr style="background:#f3f3f3"><td style="padding:8px"><b>Verlängerungspreis</b></td><td style="padding:8px">CHF 14.90/Monat</td></tr>
</table>
<br>
<div style="text-align:center">
  <a href="#" onclick="return false" style="background:#0078d4;color:#fff;padding:12px 28px;border-radius:4px;text-decoration:none;font-weight:bold;display:inline-block">Jetzt verlängern</a>
</div>
<p style="font-size:12px;color:#666;margin-top:20px">Microsoft Corporation | One Microsoft Way, Redmond, WA 98052<br>© 2026 Microsoft. Alle Rechte vorbehalten.</p>`,
    clues: [
      { element: "from_email", text: "Domain «microsoft-365-support.net» – echte Microsoft-Mails kommen von @microsoft.com oder @account.microsoft.com." },
      { element: "urgency", text: "Das Ablaufdatum ist «übermorgen» – Druck durch kurze Frist soll zum schnellen Klicken verleiten." },
      { element: "link", text: "Der «Jetzt verlängern»-Button führt nicht zu microsoft.com – Maus-Hover würde eine fremde URL zeigen." },
      { element: "footer", text: "Ein echter Microsoft-Footer täuscht über die gefälschte Absender-Domain hinweg – professionelles Erscheinungsbild als Tarnung." }
    ],
    explanation: "Sehr glaubwürdige Phishing-Mail mit echtem Microsoft-Branding. Der entscheidende Hinweis ist die Absender-Domain «microsoft-365-support.net» statt microsoft.com, kombiniert mit einem verdächtigen Verlängerungs-Link."
  },
  {
    id: 4,
    isPhishing: false,
    difficulty: "leicht",
    from_name: "HR – Anna Keller",
    from_email: "a.keller@firma.ch",
    to: "max.muster@firma.ch",
    subject: "Erinnerung: Mitarbeitergespräch am Donnerstag",
    date: "Di, 28. Mai 2026, 14:30",
    body: `<p>Hallo Max</p>
<p>Ich möchte dich kurz an unser vereinbartes Mitarbeitergespräch am Donnerstag, 30. Mai um 10:00 Uhr erinnern.</p>
<p>Wir treffen uns wie besprochen in Raum 3.12. Du musst nichts vorbereiten – wir sprechen über deine aktuelle Situation und die Ziele für das zweite Halbjahr.</p>
<p>Bis Donnerstag!<br>Anna</p>
<p style="color:#888;font-size:13px">Anna Keller | HR Business Partner<br>Firma AG | Tel. 044 123 45 89</p>`,
    clues: [
      { element: "from_email", text: "Die Absender-Domain «firma.ch» ist intern – der Name stimmt mit der Signatur überein." },
      { element: "tone", text: "Persönlicher, kollegialer Ton mit Vorname – kein unpersönliches «Sehr geehrter Kunde»." },
      { element: "no_link", text: "Keine Links, keine Buttons, keine Aufforderung zur Dateneingabe." },
      { element: "content", text: "Konkreter, nachvollziehbarer Inhalt – Raumnummer, Datum, Uhrzeit." }
    ],
    explanation: "Legitime interne Mail: bekannte Absenderin mit korrekter Firmendomain, persönlicher Ton, kein verdächtiger Inhalt und keine Links."
  },
  {
    id: 5,
    isPhishing: true,
    difficulty: "mittel",
    from_name: "Postfinance",
    from_email: "service@postfinance-secure.ch",
    to: "max.muster@firma.ch",
    subject: "Wichtige Mitteilung zu Ihrem Konto",
    date: "Do, 23. Mai 2026, 08:01",
    body: `<p>Sehr geehrter Herr Muster</p>
<p>Im Rahmen unserer regelmässigen Sicherheitsprüfung wurden Unregelmässigkeiten bei Ihrem Konto festgestellt. Zur Sicherheit Ihres Kontos bitten wir Sie, Ihre Identität zu bestätigen.</p>
<p>Bitte klicken Sie auf den untenstehenden Link, um den Verifizierungsprozess abzuschliessen:</p>
<div style="text-align:center;margin:16px 0">
  <a href="#" onclick="return false" style="background:#FFCC00;color:#000;padding:12px 28px;border-radius:4px;text-decoration:none;font-weight:bold;display:inline-block">Identität bestätigen</a>
</div>
<p>Falls Sie diese Anfrage nicht erhalten möchten, ignorieren Sie diese E-Mail.</p>
<p>Freundliche Grüsse<br>PostFinance AG<br>Mingerstrasse 20, 3030 Bern</p>`,
    clues: [
      { element: "from_email", text: "«postfinance-secure.ch» ist nicht die offizielle Domain. Echte PostFinance-Mails kommen von @postfinance.ch." },
      { element: "vague", text: "Vage Formulierung «Unregelmässigkeiten festgestellt» ohne konkrete Angaben – echte Banken nennen Einzelheiten." },
      { element: "link", text: "Der Button zur «Identitätsbestätigung» führt auf eine externe Seite – Banken fragen Daten nie per E-Mail ab." },
      { element: "address", text: "Eine echte Adresse im Footer kann leicht kopiert werden und gibt keine Echtheit-Garantie." }
    ],
    explanation: "Klassische Bank-Phishing-Mail: gefälschte Domain, vage Sicherheitswarnung und Aufforderung zur Dateneingabe über einen externen Link. Echte Banken kontaktieren Sie telefonisch oder per Brief bei echten Sicherheitsproblemen."
  },
  {
    id: 6,
    isPhishing: true,
    difficulty: "schwer",
    from_name: "Max Brunner (CEO)",
    from_email: "m.brunner@firma-ag.com",
    to: "max.muster@firma.ch",
    subject: "Vertraulich: Dringende Überweisung nötig",
    date: "Fr, 24. Mai 2026, 17:58",
    body: `<p>Hallo Max</p>
<p>Ich bin gerade in einem Kundentermin und kann nicht telefonieren. Ich brauche dringend deine Hilfe für eine vertrauliche Transaktion – wir finalisieren heute noch einen wichtigen Partnervertrag.</p>
<p>Kannst du bitte sofort CHF 18'500 an folgendes Konto überweisen? Alles weitere erkläre ich dir nachher persönlich.</p>
<p><strong>Empfänger:</strong> Nexus Consulting GmbH<br>
<strong>IBAN:</strong> DE89 3704 0044 0532 0130 00<br>
<strong>Verwendungszweck:</strong> Partnervertrag Mai 2026</p>
<p>Bitte bestätige kurz per Mail wenn erledigt. Absolute Vertraulichkeit – bitte nicht mit anderen besprechen.</p>
<p>Danke & Grüsse<br>Max Brunner</p>`,
    clues: [
      { element: "from_email", text: "Domain «firma-ag.com» statt «firma.ch» – eine sehr ähnliche, aber falsche Domain (CEO-Fraud / BEC-Angriff)." },
      { element: "urgency", text: "«Dringend», «sofort», «heute noch» – künstlicher Zeitdruck verhindert sorgfältiges Nachdenken." },
      { element: "secrecy", text: "«Absolute Vertraulichkeit – nicht mit anderen besprechen» – isoliert das Opfer von Kollegen, die warnen könnten." },
      { element: "unusual", text: "Überweisungsaufträge per E-Mail ohne vorherige Absprache sind unüblich und sollten immer telefonisch verifiziert werden." }
    ],
    explanation: "CEO-Fraud (Business Email Compromise): Angreifer imitieren einen Vorgesetzten mit ähnlicher Domain, kombinieren Zeitdruck mit Geheimhaltungsaufforderung. Überweisungen niemals nur aufgrund einer E-Mail durchführen – immer telefonisch beim Absender verifizieren."
  }
];

var state = {
  current: 0,
  answers: [],
  score: 0,
  started: false,
  finished: false,
  hintsUsed: 0
};

var cluesRevealed = [];

function startSimulator() {
  state.started = true;
  state.current = 0;
  state.answers = [];
  state.score = 0;
  state.hintsUsed = 0;
  showScreen("email-screen");
  loadEmail(0);
  updateProgress();
}

function loadEmail(idx) {
  cluesRevealed = [];
  var email = EMAILS[idx];
  document.getElementById("email-counter").textContent = (idx + 1) + " / " + EMAILS.length;
  document.getElementById("email-from-name").textContent = email.from_name;
  document.getElementById("email-from-addr").textContent = "<" + email.from_email + ">";
  document.getElementById("email-to").textContent = email.to;
  document.getElementById("email-subject").textContent = email.subject;
  document.getElementById("email-date").textContent = email.date;
  document.getElementById("email-body").innerHTML = email.body;
  document.getElementById("difficulty-badge").textContent = "Schwierigkeit: " + email.difficulty;
  document.getElementById("difficulty-badge").className = "difficulty-badge diff-" + email.difficulty;
  document.getElementById("feedback-area").style.display = "none";
  document.getElementById("answer-buttons").style.display = "flex";
  document.getElementById("next-btn").style.display = "none";
  document.getElementById("hint-count").textContent = email.clues.length;
  document.getElementById("hints-list").innerHTML = "";
  document.getElementById("hint-area").style.display = "none";
  document.getElementById("hint-toggle").textContent = "💡 Hinweise einblenden";
  document.getElementById("hint-toggle").setAttribute("data-open", "false");
}

function revealHint() {
  var email = EMAILS[state.current];
  var nextIdx = cluesRevealed.length;
  if (nextIdx >= email.clues.length) return;

  cluesRevealed.push(nextIdx);
  state.hintsUsed++;
  renderHints();

  var toggle = document.getElementById("hint-toggle");
  var area = document.getElementById("hint-area");
  area.style.display = "block";
  toggle.setAttribute("data-open", "true");
  toggle.textContent = "🙈 Hinweise ausblenden";

  var remaining = email.clues.length - cluesRevealed.length;
  document.getElementById("hint-count").textContent = remaining;
  if (remaining === 0) {
    document.getElementById("hint-toggle").innerHTML = "✅ Alle Hinweise aufgedeckt";
  }
}

function toggleHints() {
  var toggle = document.getElementById("hint-toggle");
  var area = document.getElementById("hint-area");
  var isOpen = toggle.getAttribute("data-open") === "true";
  if (isOpen) {
    area.style.display = "none";
    toggle.setAttribute("data-open", "false");
    toggle.textContent = "💡 Hinweise einblenden";
  } else {
    if (cluesRevealed.length === 0) { revealHint(); return; }
    area.style.display = "block";
    toggle.setAttribute("data-open", "true");
    toggle.textContent = "🙈 Hinweise ausblenden";
  }
}

function renderHints() {
  var email = EMAILS[state.current];
  var list = document.getElementById("hints-list");
  list.innerHTML = "";
  for (var i = 0; i < cluesRevealed.length; i++) {
    var clue = email.clues[cluesRevealed[i]];
    var li = document.createElement("li");
    li.className = "hint-item hint-in";
    li.innerHTML = "<span class='hint-num'>" + (i + 1) + "</span><span>" + clue.text + "</span>";
    list.appendChild(li);
  }
}

function submitAnswer(isPhishingGuess) {
  var email = EMAILS[state.current];
  var correct = (isPhishingGuess === email.isPhishing);
  var hintsForThisEmail = cluesRevealed.length;
  var points = 0;

  if (correct) {
    if (hintsForThisEmail === 0) points = 2;
    else if (hintsForThisEmail <= 1) points = 1.5;
    else points = 1;
  }

  state.answers.push({
    emailId: email.id,
    correct: correct,
    isPhishing: email.isPhishing,
    guessed: isPhishingGuess,
    hints: hintsForThisEmail,
    points: points
  });
  state.score += points;

  showFeedback(correct, email, isPhishingGuess);
  document.getElementById("answer-buttons").style.display = "none";
  document.getElementById("next-btn").style.display = "block";
  document.getElementById("next-btn").textContent =
    (state.current + 1 < EMAILS.length) ? "Nächste Mail →" : "Auswertung anzeigen";
  document.getElementById("hint-area").style.display = "block";
  document.getElementById("hint-toggle").style.display = "none";
  renderAllHints();
}

function renderAllHints() {
  var email = EMAILS[state.current];
  var list = document.getElementById("hints-list");
  list.innerHTML = "";
  for (var i = 0; i < email.clues.length; i++) {
    var clue = email.clues[i];
    var li = document.createElement("li");
    li.className = "hint-item" + (i < cluesRevealed.length ? "" : " hint-new");
    li.innerHTML = "<span class='hint-num'>" + (i + 1) + "</span><span>" + clue.text + "</span>";
    list.appendChild(li);
  }
}

function showFeedback(correct, email, guessed) {
  var area = document.getElementById("feedback-area");
  area.style.display = "block";
  area.className = "feedback-area " + (correct ? "feedback-correct" : "feedback-wrong");

  var icon = correct ? "✅" : "❌";
  var title = correct
    ? (email.isPhishing ? "Richtig – das ist eine Phishing-Mail!" : "Richtig – das ist eine legitime Mail!")
    : (email.isPhishing ? "Falsch – das war eine Phishing-Mail!" : "Falsch – das war eine legitime Mail!");

  area.innerHTML = "<p class='feedback-title'>" + icon + " " + title + "</p>" +
    "<p class='feedback-explanation'>" + email.explanation + "</p>";
}

function nextEmail() {
  state.current++;
  if (state.current >= EMAILS.length) {
    showResults();
  } else {
    loadEmail(state.current);
    updateProgress();
  }
}

function updateProgress() {
  var pct = (state.current / EMAILS.length) * 100;
  document.getElementById("progress-bar").style.width = pct + "%";
  document.getElementById("progress-text").textContent = state.current + " von " + EMAILS.length + " E-Mails bewertet";
}

function showResults() {
  state.finished = true;
  showScreen("results-screen");

  var maxScore = EMAILS.length * 2;
  var pct = Math.round((state.score / maxScore) * 100);

  document.getElementById("result-score").textContent = Math.round(state.score * 10) / 10;
  document.getElementById("result-max").textContent = maxScore;
  document.getElementById("result-pct").textContent = pct + "%";

  var correct = state.answers.filter(function(a) { return a.correct; }).length;
  document.getElementById("result-correct").textContent = correct;
  document.getElementById("result-total").textContent = EMAILS.length;

  var rating = "";
  if (pct >= 90) rating = "🏆 Ausgezeichnet! Sie haben ein sehr gutes Gespür für Phishing.";
  else if (pct >= 70) rating = "👍 Gut gemacht! Ein paar Knacknüsse waren dabei.";
  else if (pct >= 50) rating = "📚 Solide Basis – mit etwas Übung werden Sie sicherer.";
  else rating = "⚠️ Vorsicht geboten – Phishing-Mails sind tückisch. Üben Sie weiter!";
  document.getElementById("result-rating").textContent = rating;

  renderResultDetails();
  updateProgress();

  // SCORM reporting
  var passed = pct >= 60;
  SCORM.finish(pct, passed);
}

function renderResultDetails() {
  var container = document.getElementById("result-details");
  container.innerHTML = "";
  for (var i = 0; i < state.answers.length; i++) {
    var a = state.answers[i];
    var email = EMAILS.find(function(e) { return e.id === a.emailId; });
    var div = document.createElement("div");
    div.className = "result-item " + (a.correct ? "result-ok" : "result-fail");
    div.innerHTML =
      "<div class='result-item-header'>" +
        "<span class='result-icon'>" + (a.correct ? "✅" : "❌") + "</span>" +
        "<span class='result-subject'>" + email.subject + "</span>" +
        "<span class='result-badge " + (email.isPhishing ? "badge-phishing" : "badge-legit") + "'>" +
          (email.isPhishing ? "Phishing" : "Legitim") + "</span>" +
      "</div>" +
      "<div class='result-sub'>" +
        "Ihre Antwort: <strong>" + (a.guessed ? "Phishing" : "Legitim") + "</strong> · " +
        "Hinweise genutzt: " + a.hints + " · Punkte: " + (Math.round(a.points * 10) / 10) +
      "</div>";
    container.appendChild(div);
  }
}

function restartSimulator() {
  state = { current: 0, answers: [], score: 0, started: false, finished: false, hintsUsed: 0 };
  showScreen("start-screen");
}

function showScreen(id) {
  var screens = ["start-screen", "email-screen", "results-screen"];
  screens.forEach(function(s) {
    document.getElementById(s).style.display = (s === id) ? "block" : "none";
  });
}

// Init on load
window.addEventListener("DOMContentLoaded", function() {
  showScreen("start-screen");
});
